# Periodismo de datos en UC3M

Notras sobre **Periodismo de datos** en *UC3M*
- Periodismo
- Visualización
- Datos


**URLS**
Se componen de dos partes:
- Protocolo: https://
- Domino: *.com*, *.es* 
- Carpetas: las separa del dominio una barra
https:// dominio / carpetas


tipos de formatos de datos:
- CSV: Coma Separated Values *lo de excel*
- JSON: Java Script Object Notation
- XML 

Para escribir fechas en github hay que usar este formato: YYYY-MM-DD 2019-09-28

Los datos booleanos son los que son de una posibilidad u otra, como por ejemplo, true or false

**REPOSITORIO**
->
